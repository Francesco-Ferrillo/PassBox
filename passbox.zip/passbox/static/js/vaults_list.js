function openModal(id) {
    const modal = document.getElementById("modal-" + id);
    modal.style.display = "block";
}

function closeModal(id) {
    const modal = document.getElementById(`modal-${id}`);
    modal.style.display = "none";
    window.location.href = "{{ url_for('vaults_list')}}";
}

function confirmDelete(url) {
    if (confirm("Are you sure you want to eliminate this vault?")) {
        window.location.href = url;
    }
}
