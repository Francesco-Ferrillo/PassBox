function generateStrongPassword() {
    const length = 16; // Password più lunga e sicura
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+[]{}|;:,.<>?";
    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }
    return password;
}

function suggestPassword(fieldId) {
    const generatedPassword = generateStrongPassword();
    const passwordField = document.getElementById(fieldId);
    passwordField.value = generatedPassword;
    passwordField.type = "text"; // Mostra la password generata
}

function togglePasswordVisibility(fieldId) {
    const passwordField = document.getElementById(fieldId);
    passwordField.type = passwordField.type === "password" ? "text" : "password";
}