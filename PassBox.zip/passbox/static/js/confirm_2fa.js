

document.addEventListener("DOMContentLoaded", function () {
    const popupContainer = document.getElementById("popup-container");
    popupContainer.classList.add("show"); // Aggiunge la classe per attivare l'animazione
});
